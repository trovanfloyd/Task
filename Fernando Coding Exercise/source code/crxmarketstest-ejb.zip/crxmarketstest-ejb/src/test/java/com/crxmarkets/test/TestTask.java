package com.crxmarkets.test;

import org.junit.Assert;
import org.junit.Test;

import com.crxmarkets.task.SurfaceWaterProblem;

public class TestTask {
	
	
	@Test
	public void testBasic1() {
		int[] surface1 = {4, 1, 1, 0, 2, 3}; 
		
		SurfaceWaterProblem surfaceWaterProblem = new SurfaceWaterProblem();
		int volume = surfaceWaterProblem.calculateRemainedWater(surface1);
		
		Assert.assertEquals(8, volume);
	}
	
	@Test
	public void testBasic2() {
		
		int[] surface3 = {9, 3, 5, 3, 6, 0, 1, 4, 5, 2, 6}; 
		
		SurfaceWaterProblem surfaceWaterProblem = new SurfaceWaterProblem();
		int volume = surfaceWaterProblem.calculateRemainedWater(surface3);
		
		Assert.assertEquals(25, volume);
	}
	
	@Test
	public void testWithNoEnoughElements() {
		
		int[] surface2 = {0, 1}; 
		
		SurfaceWaterProblem surfaceWaterProblem = new SurfaceWaterProblem();
		int volume = surfaceWaterProblem.calculateRemainedWater(surface2);
		
		Assert.assertEquals(0, volume);
	}
	
	@Test
	public void testWithNoRemainedWater() {
		
		int[] surface4 = {3, 3, 4, 2, 2}; 
		
		SurfaceWaterProblem surfaceWaterProblem = new SurfaceWaterProblem();
		int volume = surfaceWaterProblem.calculateRemainedWater(surface4);
		
		Assert.assertEquals(0, volume);
	}
}
