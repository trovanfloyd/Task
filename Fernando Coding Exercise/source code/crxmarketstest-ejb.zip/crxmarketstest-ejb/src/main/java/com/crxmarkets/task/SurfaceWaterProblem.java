package com.crxmarkets.task;

import java.util.Arrays;
import java.util.IntSummaryStatistics;

/**
 * 
 * @author Fernando Freitas
 *
 */
public class SurfaceWaterProblem {

	/**
	 * Calculates the volume of water which remained after the rain
	 * @param surfaceProfile array that represents profile of a surface
	 * @return volume in units of water which remained after the rain
	 */
	public int calculateRemainedWater(int[] surfaceProfile) {
		int volume = 0;

		for (int i = 1; i < surfaceProfile.length - 1; i++) {
			// Split array into two parts
			int[] left = Arrays.copyOfRange(surfaceProfile, 0, i);
			int[] right = Arrays.copyOfRange(surfaceProfile, i + 1, surfaceProfile.length);

			int minHeight = getMinHeight(left, right);
			if (minHeight - surfaceProfile[i] > 0) {
				volume += minHeight - surfaceProfile[i];
			}
		}

		return volume;
	}

	/**
	 * Gets the min value between the max height left and max height right
	 * 
	 * @param left  array that contains the left elements from the current indice
	 * @param righ  array that contains the right elements from the current indice
	 * @return min value between the max height left and max height right
	 */
	public int getMinHeight(int[] left, int[] righ) {

		int maxLeft = -1;
		int maxRight = -1;

		IntSummaryStatistics statLeft = Arrays.stream(left).summaryStatistics();
		maxLeft = statLeft.getMax();

		IntSummaryStatistics statRight = Arrays.stream(righ).summaryStatistics();
		maxRight = statRight.getMax();

		return Math.min(maxLeft, maxRight);
	}
}
